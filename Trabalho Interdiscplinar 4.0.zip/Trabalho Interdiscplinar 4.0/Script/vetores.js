var vetPiloto = ['John Smith', 'Lucas Silva', 'Liam Jones', 'Noah Brown', 'William Davis', 'James Taylor', 'Benjamin Wilson', 'Henry Thomas', 'Daniel Johnson', 'Michael Anderson', 'Alexander Thompson', 'David Garcia', 'Joseph Martin', 'Matthew Rodrigues', 'Andrew Robinson', 'Ryan Martinez'];

var vetEquipe = ["Full Time Sports", "Full Time Sports", "Cimed Racing", "Cimed Racing", "Shell V-Power Racing Team", "Shell V-Power Racing Team", "TMG Racing", "TMG Racing", "Vogel Motorsport", "Vogel Motorsport", "Ipiranga Racing", "Ipiranga Racing", "KTF Sports", "KTF Sports", "Crown Racing", "Crown Racing"];


var vetCorrida1 = [13, 11, 14, 7, 10, 4, 8, 2, 12, 1, 16, 5, 6, 15, 3, 9];
var vetCorrida2 = [7, 6, 13, 1, 3, 11, 8, 15, 12, 5, 4, 14, 9, 16, 2, 10];
var vetCorrida3 = [1, 16, 9, 15, 14, 4, 2, 8, 13, 10, 7, 11, 6, 5, 12, 3];
var vetCorrida4 = [16, 2, 12, 11, 13, 4, 7, 8, 15, 3, 9, 10, 6, 1, 5, 14];
var vetCorrida5 = [15, 6, 14, 10, 2, 12, 5, 9, 1, 8, 7, 16, 11, 3, 13, 4];

var vetPontuacaoPilotos = [16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1];//Vetor de apoio que guarda qual será a pontuação de um piloto pela ordem de chegada, na posição 0 guarda a do primeiro lugar e vai decrescendo até guardar a posição do último lugar