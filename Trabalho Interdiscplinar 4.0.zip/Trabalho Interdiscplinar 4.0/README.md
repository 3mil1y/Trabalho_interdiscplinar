Trabalho Interdisciplinar
